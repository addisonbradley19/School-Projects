﻿using System;

namespace PersonalCalendar
{
    //internal class Event
    public class Event
    {
        internal string eventTitle;         //hold all the values for an event
        internal string eventDate;
        internal int eventStartTime;
        internal int eventEndTime;
        internal string eventContent;
        internal int eventID;
        internal string eventParticipants;
        internal string eventLocation;
        internal string eventReminder;

        public string getDate()
        {
            return eventDate;
        }

        public string getStartTime()
        {
            int t1 = eventStartTime;            //get start time by calculating the the time from the database and turning it into a working string that represents what the string is supposed to be.
            t1 = t1 % 1200;
            int j1;
           
            j1 = t1 % 100;
            t1 = t1 / 100;

            TimeSpan result = new TimeSpan(0, t1, j1, 0);

            string spaces = new string(' ', 14);
            string s1 = result.ToString("hh':'mm");
            
            return s1;
        }
        
        public string getStartAP()
        {
            int o1 = eventStartTime;                //get the whether a start time is am or pm
            string m1 = " ";

            if (o1 / 1200 == 1)
            {
                m1 = "PM";
            }
            else
            {
                m1 = "AM";
            }

            return m1;
        }

        public string getEndAP()
        {
            int o2 = eventEndTime;          //get whether or not a end time is am or pm
            string m2 = " ";
            if (o2 / 1200 == 1)
            {
                m2 = "PM";
            }
            else
            {
                m2 = "AM";
            }
            return m2;
        }

        public string getEndTime()          //turn end time from the database from a military time int to 12 hour time string
        {
            int t2 = eventEndTime;
            int j2;

            t2 = t2 % 1200;
            j2 = t2 % 100;
            t2 = t2 / 100;

            TimeSpan result2 = new TimeSpan(0, t2, j2, 0);
            string s2 = result2.ToString("hh':'mm");
            return s2;
        }

        public string getTitle()
        {
            return eventTitle;
        }
    }
}