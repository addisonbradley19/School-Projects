﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonalCalendar
{
    public partial class Form1 : Form
    {
        int[] sTime = new int[] { 100, 115, 130, 145, 200, 215, 230, 245, 300, 315, 330, 345, 400, 415, 430, 445, 500, 515, 530, 545, 600, 615, 630, 645, 700, 715, 730, 745, 800, 815, 830, 845, 900, 915, 930, 945, 1000, 1015, 1030, 1045, 1100, 1115, 1130, 1145, 1200, 1215, 1230, 1245 };           //array of ints to better transfer the values selected by the start time and end time list box into actual ints
        public Form1()
        {
            InitializeComponent();
        }

        ArrayList eList = new ArrayList();          //array list to store events found for the users currently selected day
        ArrayList mList = new ArrayList();             // array list to store events found for the users currently selected month
        string nTitle = " ";                //variables for the whole program to use to store the values of an event such as title (nTitle), event# (eN), and date (nDate)
        string nDate = " ";
        string nStartTime = " ";
        string nEndTime = " ";
        string nlocation = " ";
        string nparticipants = " ";
        string nContent = " ";
        string nreminder = " ";
        int stTime;
        int enTime;
        string stAP;
        string enAP;
        int eN = 0;

        private void eventStart(object sender, EventArgs e)
        {
            panel2.Hide();          //hide the list panel
            panel7.Show();          //show the blank entry form
            panel4.Show();          //show the save and exit buttons 
            button1.Hide();         //hide the main scren buttons
            button2.Hide();
            button3.Hide();
            button4.Hide();
            comboBox1.SelectedIndex = 0;        //set the selected index to all choices such as AM or PM, the current start or end times, and the reminder time
            comboBox2.SelectedIndex = 0;
            comboBox3.SelectedIndex = 0;
            comboBox4.SelectedIndex = 0;
            comboBox5.SelectedIndex = 0;
            //textBox1.Text = "";                 // reset all textboxes (except date) for the blank form so there is no carry over from previous creations
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";

            comboBox6.Items.Clear();        //clear all text options from Contact box

            DataTable myTable = new DataTable();        //means of holding 
            string dateString = monthCalendar1.SelectionRange.Start.ToShortDateString();        //get the currently selected date on the user calendar
            string connStr = "server=csdatabase.eku.edu;user=addison_bradley19;database=bradley;port=3306;password=Bradley19;";     //string that contains the info to connect to the database
            MySqlConnection conn = new MySqlConnection(connStr);        //connection to the server
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT Name FROM contacts";       //sql which gets all the names in the contacts to be connected
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);        //fills myTable 
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)
            {
                string co;
                co = row["Name"].ToString();
                comboBox6.Items.Add(co);
            }
            comboBox6.SelectedIndex = -1;

        }


        private void CalendarClicked(object sender, DateRangeEventArgs e)    //this is for the action of the user pressing a date on the calendar or changing the month on the calendar. This controls all actions involving 
        {
            textBox1.Text = monthCalendar1.SelectionRange.Start.ToString("MM/dd/yyyy");     //textbox1 is the date textbox for the blank form in event creation. Once the user selects a date to be turned into a string in the 01/01/1997 format of dates to be put into the textbox
            textBox18.Text =  monthCalendar1.SelectionRange.Start.ToString("MM/dd/yyyy");   //textbox1 is the date textbox for the editing form event editing. Once the user selects a date to be turned into a string in the 01/01/1997 format of dates to be put into the textbox     

            listBox1.Items.Clear();     //clears all dates shown in the main screen list box, because user has now just changed  

            ArrayList eventList = new ArrayList();  //a list to save the events
            //prepare an SQL query to retrieve all the events on the same, specified date
            DataTable myTable = new DataTable();
            string dateString = monthCalendar1.SelectionRange.Start.ToString("MM/dd/yyyy");
            string connStr = "server=csdatabase.eku.edu;user=addison_bradley19;database=bradley;port=3306;password=Bradley19;";     //connection to the database
            MySqlConnection conn = new MySqlConnection(connStr);        //connect
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT * FROM calendar WHERE date=@myDate ORDER BY startTime ASC";        //SQL statement to select all  information from the events that share selected days date organized by start Time
                MySqlCommand cmd = new MySqlCommand(sql, conn);                             //prepeare command
                cmd.Parameters.AddWithValue("@myDate", dateString);                 //collect the date selected so that it may be inserted into the sql statement.
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);             //perform action
                myAdapter.Fill(myTable);                                            //fill all contents wit the infor
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)           //for all information stored in mytable, we will transform said information into an arraylist for item event
            {
                Event newEvent = new Event();           //create new event to store all information
                newEvent.eventTitle = row["title"].ToString();      //gather all information
                newEvent.eventDate = row["date"].ToString();
                newEvent.eventStartTime = Int32.Parse(row["startTime"].ToString());
                newEvent.eventEndTime = Int32.Parse(row["endTime"].ToString());
                newEvent.eventContent = row["content"].ToString();
                newEvent.eventID = Int32.Parse(row["eventID"].ToString());
                newEvent.eventParticipants = row["participants"].ToString();
                newEvent.eventLocation = row["location"].ToString();
                newEvent.eventReminder = row["reminder"].ToString();
                eventList.Add(newEvent);
            }
            eList = eventList;      //store the all information in the event list created into the wide last event list elist that has all events for the selected day
            //return eventList;  //return the event list
            for (int i=0; i < eventList.Count; i++)         //takes the events just grabbed for the selected day and adds them to the listbox on the main page
            {                                           //for every event in eventlist
                Event thisEvent = (Event)eventList[i];      //current spot in eventlist gets its event turned into a seperate event for reuse purposes
                listBox1.Items.Add(thisEvent.getDate() + "    " + thisEvent.getTitle());        //take the extracted event and add the date and title info  into the listbox on hte main page
            }
            if(eList.Count != 0) {      //make the selected index of the new listbox be the first one everytime a new date is clicked
                listBox1.SelectedIndex = 0; //if there is no event taken, then just do select an index
            }


            
        }


        private void viewMonthData(object sender, EventArgs e)
        {

            DateTime temp = monthCalendar1.SelectionRange.Start;        //turn currently selected date into datetime for editing purposed
            string mo = temp.Month.ToString();                          //turn the currently selected month into a string
            string con = temp.ToString("MMMM");                         //take the month of the currently selected date and turn it into the word of said month such December or April
            string str = temp.Year.ToString();                          //turn the year into a string
            string cmb = con + " " + str;                               //combine name of month with year 

            label13.Text = cmb;                                         //turn the label for the month display into the name of the month and year on display
            panel8.Visible = true;                                      //display the month
            panel6.Show();                                              //display the buttons for month display
            panel2.Hide();                                              //hide main page
            button1.Hide();                                             //hide buttons from main page
            button2.Hide();
            button3.Hide();
            button4.Hide();
            monthCalendar1.Hide();                                      //hide the calendar

            listBox2.Items.Clear();                                     //remove all previous items from the month display listbox

            DataTable myTable = new DataTable();            //gather all information into the data table
            ArrayList eventList = new ArrayList();
            string connStr = "server=csdatabase.eku.edu;user=addison_bradley19;database=bradley;port=3306;password=Bradley19;";     //connection to database
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");    
                conn.Open();        //open connection
                string sql = "SELECT * FROM calendar WHERE date LIKE @month AND date LIKE @year ORDER BY date ASC, startTime ASC;";     //sql that states we want events that match month and year the user clicked on
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@month", mo + "%");    //take events that start with the same month
                cmd.Parameters.AddWithValue("@year", "%" + str);       // add to the statement to take events that match the year the user selected
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);     //perform sql statement
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)           //add all events collected into a new event list that will later be converted into another eventlist called mList
            {
                Event newEvent = new Event();
                newEvent.eventTitle = row["title"].ToString();
                newEvent.eventDate = row["date"].ToString();
                newEvent.eventStartTime = Int32.Parse(row["startTime"].ToString());
                newEvent.eventEndTime = Int32.Parse(row["endTime"].ToString());
                newEvent.eventContent = row["content"].ToString();
                newEvent.eventID = Int32.Parse(row["eventID"].ToString());
                newEvent.eventParticipants = row["participants"].ToString();
                newEvent.eventLocation = row["location"].ToString();
                newEvent.eventReminder = row["reminder"].ToString();
                eventList.Add(newEvent);
            }
            mList = eventList;

            for (int i = 0; i < eventList.Count; i++)       //display the title and date of all the events taken that match everything
            {
                Event thisEvent = (Event)eventList[i];
                listBox2.Items.Add(thisEvent.getDate() + "    " + thisEvent.getTitle());
            }
            if (eventList.Count != 0)       //if their was no events grabbed, do not add an automatic selected index. If there is an event added, then the user simply makes the first index the currently selected index in month dispaly list box
            {
                listBox2.SelectedIndex = 0;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ArrayList eventList = new ArrayList();  //a list to save the events
            //prepare an SQL query to retrieve all the events on the same, specified date
            DataTable myTable = new DataTable();
            string dateString = monthCalendar1.SelectionRange.Start.ToString("MM/dd/yyyy");     //load all events that match the current date and put them into the list box on main page
            string connStr = "server=csdatabase.eku.edu;user=addison_bradley19;database=bradley;port=3306;password=Bradley19;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT * FROM calendar WHERE date=@myDate ORDER BY startTime ASC";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@myDate", dateString);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)
            {
                Event newEvent = new Event();
                newEvent.eventTitle = row["title"].ToString();
                newEvent.eventDate = row["date"].ToString();
                newEvent.eventStartTime = Int32.Parse(row["startTime"].ToString());
                newEvent.eventEndTime = Int32.Parse(row["endTime"].ToString());
                newEvent.eventContent = row["content"].ToString();
                newEvent.eventID = Int32.Parse(row["eventID"].ToString());
                newEvent.eventParticipants = row["participants"].ToString();
                newEvent.eventLocation = row["location"].ToString();
                newEvent.eventReminder = row["reminder"].ToString();
                eventList.Add(newEvent);
            }
            eList = eventList;
            //return eventList;  //return the event list
            for (int i = 0; i < eventList.Count; i++)
            {
                Event thisEvent = (Event)eventList[i];
                listBox1.Items.Add(thisEvent.getDate() + "    " + thisEvent.getTitle());
            }
            if (eList.Count != 0)
            {
                listBox1.SelectedIndex = 0;
            }
        }

        private void exitProgram(object sender, EventArgs e)
        {
            this.Close();
        }

        private void viewListofEvents(object sender, EventArgs e)
        {
            int ind = listBox1.SelectedIndex;           //take the selected index on the list box as the event the user wishes to see
            if(eList.Count != 0)            //if their is nothing to take from the list box on main page (it's empty) don't allow any further action
            {
                Event thisEvent = (Event)eList[ind];

                nTitle = thisEvent.getTitle();                                      //if there is a selected index on the main page list box then turn the event on the selected index as it's own individual event to take apart all aspects and inserted into seperate variables
                nDate = thisEvent.getDate();
                nStartTime = thisEvent.getStartTime() + " " + thisEvent.getStartAP();           //event has a built in means of turning the integer inserted into the database and transform them into dates along with extracting the possible AM or PM values from them
                nEndTime = thisEvent.getEndTime() + " " + thisEvent.getEndAP();                 //do the same with both
                nlocation = thisEvent.eventLocation;
                nparticipants = thisEvent.eventParticipants;
                nContent = thisEvent.eventContent;
                nreminder = thisEvent.eventReminder;
                eN = thisEvent.eventID;

                textBox13.Text = nTitle;            //insert the seperated values of thisEvent (which was originally the event on the selected index of eList chosen from the list box on main page) and add them to the view page
                textBox11.Text = nStartTime;
                textBox12.Text = nEndTime;
                textBox9.Text = nreminder;
                textBox10.Text = nlocation;
                textBox6.Text = nparticipants;
                textBox7.Text = nContent;
                textBox8.Text = nDate;

                monthCalendar1.Visible = false;         //hide the main page and main page buttons but make visible the blank form and the save and exit buttons for blank form
                button1.Hide();
                button2.Hide();
                button3.Hide();
                button4.Hide();
                panel2.Visible = false;
                panel9.Visible = true;
                panel3.Visible = true;
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ViewToMain(object sender, EventArgs e)
        {
            monthCalendar1.Visible = true;          //return from the view panel to the main page
            panel3.Visible = false;                 //by hiding the buttons and page for view page
            panel9.Visible = false;                 //and making visible the pages for main page
            panel2.Visible = true;
            button1.Show();
            button2.Show();
            button3.Show();
            button4.Show();
        }

        private void EditingEvent(object sender, EventArgs e)
        {
            monthCalendar1.Show();          //in order to properly make the editing page appear, the calendar must be visible inorder to best
            panel9.Visible = false;         //show the edit panel and button panel for edits
            panel3.Visible = false;
            panel10.Visible = true;         //hide the view page material
            panel5.Visible = true;

            textBox18.Text = nDate;         //bring the text from the view page and add them to the edit form
            textBox17.Text = nTitle;
            textBox16.Text = nlocation;
            textBox14.Text = nparticipants;
            textBox15.Text = nContent;

            comboBox7.Items.Clear();            //clear all items from the contact combox box so that we can update the combobox appropriatly 

            string[] array = nStartTime.Split(new char[] { ' ' }, 2);           //break up the saved time into two pieces so that we have a selected index for start time, end time, startAMPM, and endAMPM
            string[] array2 = nEndTime.Split(new char[] { ' ' }, 2);
            string dStartTime = array[0];
            string dEndTime = array2[0];
            string dStartAP = array[1];
            string dEndAP = array2[1];

            DataTable myTable = new DataTable();            //go into the database to collect the contacts to be able to add them into the edit pages combo box for user selection
            string dateString = monthCalendar1.SelectionRange.Start.ToShortDateString();
            string connStr = "server=csdatabase.eku.edu;user=addison_bradley19;database=bradley;port=3306;password=Bradley19;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT Name FROM contacts";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)       
            {
                string co;
                co = row["Name"].ToString();
                comboBox7.Items.Add(co);
            }
            comboBox7.SelectedIndex = 0;            //set the selected index for the contact combo box for edit form be the first index
            

            comboBox7.SelectedIndex = 0;
            comboBox12.SelectedIndex = comboBox12.Items.IndexOf(dStartTime);        //make the selected idnex for the combo boxs for start time, end time, and the respective AMs or PMs be from the view form
            comboBox11.SelectedIndex = comboBox11.Items.IndexOf(dEndTime);
            comboBox10.SelectedIndex = comboBox10.Items.IndexOf(nreminder);
            comboBox9.SelectedIndex = comboBox4.Items.IndexOf(dStartAP);
            comboBox8.SelectedIndex = comboBox5.Items.IndexOf(dEndAP);
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ContactAdded(object sender, EventArgs e)
        {
            if (!textBox5.Text.ToString().Contains(comboBox6.SelectedItem.ToString()))      //if the textbox on the blank form does not contain the item in the comboxbox
            {
                textBox5.Text = textBox5.Text + comboBox6.SelectedItem.ToString() +  ",";       //add it into the textbox for participants with a comma on the end.
            }
            
        }
            

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void EventCreateCanceled(object sender, EventArgs e)
        {
            panel7.Hide();          //go back to the main screen and do not save any events typed
            panel4.Hide();          //remove blank form panel and show main page and all of it's buttons 
            panel2.Show();
            button1.Show();
            button2.Show();
            button3.Show();
            button4.Show();

        }

        private void EventCreationFinished(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text) || string.IsNullOrWhiteSpace(textBox3.Text) || string.IsNullOrWhiteSpace(textBox4.Text) || string.IsNullOrWhiteSpace(textBox5.Text) || comboBox1.SelectedIndex == -1 || comboBox2.SelectedIndex == -1 || comboBox3.SelectedIndex == -1 || comboBox4.SelectedIndex == -1 || comboBox5.SelectedIndex == -1)       // makes sure there is something selected for all areas, such as the start time list box and the Event Title Textbox
            {
                Form3 form3 = new Form3();      //a form which informs the user that they have not completed everything and to go back and finish
                form3.Show();   //show said form
            }
            else
            {
                stTime = 0; //int to carry the 24 hour version of the start time
                enTime = 0; //int to carry the 24 hour version of the end time
                string m1 = comboBox4.SelectedItem.ToString();       //converts the user entered AM or PM to string
                string m2 = comboBox5.SelectedItem.ToString();
                stTime = sTime[comboBox1.SelectedIndex];             //converts the user selected times into ints
                enTime = sTime[comboBox2.SelectedIndex];
                if (m1 == "PM")             //if the user selects pm
                    stTime = stTime + 1200;     //add the equivalent of 12 extra hours or 1200
                if (m2 == "PM")
                    enTime = enTime + 1200;
                if ((stTime >= 1200 && stTime < 1300) || (stTime >= 2400 && stTime < 2500))     //if the time is twelve am or twelve Pm
                    stTime = stTime - 1200;     //subtracts them so that they are the correct time in the twelve hour spectrum
                if ((enTime >= 1200 && enTime < 1300) || (enTime >= 2400 && enTime < 2500))
                    enTime = enTime - 1200;
                if (((m1 == "PM") && (m2 == "AM")) || (stTime > enTime))        //stops the user from entering times that are either impossible or would lead the user to extending the event into the next day.
                {
                    Form10 form10 = new Form10();
                    form10.Show();
                }
                else
                {
                    stAP = m1;          //save start time and end time AP for time conversion
                    enAP = m2;

                    monthCalendar1.Hide();      //hide the calendar to the left and the blank form and control panel for blank form
                    panel7.Hide();
                    panel4.Hide();
                    panel11.Show();         //display save prompt
                }
            }
        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void deletionClicked(object sender, EventArgs e)
        {
            panel9.Visible = false;         //user has clicked the delete button on the view page 
            panel3.Visible = false;         //hide all material from the user
            panel13.Visible = true;         //display prompt to delete
        }

        private void MonthToMain(object sender, EventArgs e)
        {
            panel8.Visible = false;         //return to the main page from month view by showing the main page button, the list box of daily events, and the calendar.
            button1.Show();
            button2.Show();
            button3.Show();
            button4.Show();
            panel6.Hide();
            panel2.Show();
            monthCalendar1.Show();
        }

        private void MonthEventViewChosen(object sender, EventArgs e)
        {
            int ind = listBox2.SelectedIndex;       //take the index of the chosen event from the listbox from month view
            if (mList.Count != 0)           //if there is events for that month
            {
                Event thisEvent = (Event)mList[ind];        //take the information from the selected index of the months events

                nTitle = thisEvent.getTitle();      //transform them into their own sepereate values
                nDate = thisEvent.getDate();
                nStartTime = thisEvent.getStartTime() + " " + thisEvent.getStartAP();
                nEndTime = thisEvent.getEndTime() + " " + thisEvent.getEndAP();
                nlocation = thisEvent.eventLocation;
                nparticipants = thisEvent.eventParticipants;
                nContent = thisEvent.eventContent;
                nreminder = thisEvent.eventReminder;
                eN = thisEvent.eventID;

                textBox13.Text = nTitle;        //place them into the view form
                textBox11.Text = nStartTime;
                textBox12.Text = nEndTime;
                textBox9.Text = nreminder;
                textBox10.Text = nlocation;
                textBox6.Text = nparticipants;
                textBox7.Text = nContent;
                textBox8.Text = nDate;


                panel2.Visible = false;         //hide the month view panel and buttons while displaying the view page and buttons for view page
                panel6.Visible = false;
                panel8.Visible = false;
                panel9.Visible = true;
                panel3.Visible = true;
            }
        }

        private void DeletionCanceled(object sender, EventArgs e)
        {
            panel9.Show();      //return to the view panel and view buttons
            panel13.Hide();     //hide the panel for deletion confirmation
            panel3.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void NewEventUnSaved(object sender, EventArgs e)
        {
            monthCalendar1.Show();          //go back to the previous page so further edits can be made before saving the page
            panel7.Show();                  //show the blank form and the blank form buttons
            panel4.Show();
            panel11.Hide();                 //hide the save confirmation panel
        }

        private void NewEventSaved(object sender, EventArgs e)
        {
            int cr = 0;
            nDate = textBox1.Text;       //all of the next couple of strings and values carry the values found in the user inputed areas
            nTitle = textBox3.Text;         //save the material to be added to the database table
            nlocation = textBox2.Text;
            nreminder = comboBox3.SelectedItem.ToString();
            nparticipants = textBox5.Text;
            nContent = textBox4.Text;
            string connStr = "server = csdatabase.eku.edu; user = addison_bradley19; database = bradley; port = 3306; password = Bradley19; ";
            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr);      //connects the user to my database
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string s = "SELECT MAX(eventID) FROM calendar";       //searches the database to find the largest event ID
                MySql.Data.MySqlClient.
                MySqlCommand c = new MySql.Data.MySqlClient.MySqlCommand(s, conn);      //implement the connection
                MySqlDataReader myReader = c.ExecuteReader();
                if (myReader.Read())        //if there is a date that matches,
                {
                    cr = myReader.GetInt32(0);      //save the largest event ID
                }
                myReader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            Console.WriteLine("Done.");
            eN = cr + 1;        //increase the eventID taken so that it may be the personal ID for our new event
            MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection(connStr);       //if an event does not exist for that date, then make the event. Open a new connection
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                con.Open(); //open the connection
                string sql = "INSERT INTO calendar (date, title, reminder, location, participants, content, startTime, endTime,eventID) VALUES (@udate, @utitle, @ureminder, @ulocation, @uparticipants, @ucontent, @ustartTime, @uendTime,@ueventID);";      //insert into the database
                MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@udate", nDate);       //add the values into the parameters
                cmd.Parameters.AddWithValue("@utitle", nTitle);
                cmd.Parameters.AddWithValue("@ureminder", nreminder);
                cmd.Parameters.AddWithValue("@ulocation", nlocation);
                cmd.Parameters.AddWithValue("@uparticipants", nparticipants);
                cmd.Parameters.AddWithValue("@ucontent", nContent);
                cmd.Parameters.AddWithValue("@ustartTime", stTime);
                cmd.Parameters.AddWithValue("@uendTime", enTime);
                cmd.Parameters.AddWithValue("@ueventID", eN);
                cmd.ExecuteNonQuery();      //execute query
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            monthCalendar1.Show();      //show all the material from the main page and hide the view page
            panel11.Hide();
            panel2.Visible = true;
            button1.Show();
            button2.Show();
            button3.Show();
            button4.Show();


            listBox1.Items.Clear();     //clear the list box on the main page

            ArrayList eventList = new ArrayList();  //a list to save the events
            //prepare an SQL query to retrieve all the events on the same, specified date
            DataTable myTable = new DataTable();
            string dateString = monthCalendar1.SelectionRange.Start.ToString("MM/dd/yyyy");     //find all information for the currently selected date so that the listbox on the front page is updated to match the current additons added
            
            MySqlConnection co = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                co.Open();
                string sql = "SELECT * FROM calendar WHERE date=@myDate ORDER BY startTime ASC";
                MySqlCommand cmd = new MySqlCommand(sql, co);
                cmd.Parameters.AddWithValue("@myDate", dateString);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            co.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)           //take all the events for the currently selected day and add them to list box through the eList list array. Then add them to listbox on main page
            {
                Event newEvent = new Event();
                newEvent.eventTitle = row["title"].ToString();
                newEvent.eventDate = row["date"].ToString();
                newEvent.eventStartTime = Int32.Parse(row["startTime"].ToString());
                newEvent.eventEndTime = Int32.Parse(row["endTime"].ToString());
                newEvent.eventContent = row["content"].ToString();
                newEvent.eventID = Int32.Parse(row["eventID"].ToString());
                newEvent.eventParticipants = row["participants"].ToString();
                newEvent.eventLocation = row["location"].ToString();
                newEvent.eventReminder = row["reminder"].ToString();
                eventList.Add(newEvent);
            }
            eList = eventList;
            //return eventList;  //return the event list
            for (int i = 0; i < eventList.Count; i++)
            {
                Event thisEvent = (Event)eventList[i];
                listBox1.Items.Add(thisEvent.getDate() + "    " + thisEvent.getTitle());
            }
            if (eList.Count != 0)
            {
                listBox1.SelectedIndex = 0;
            }
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void EditCanceled(object sender, EventArgs e)
        {
            monthCalendar1.Hide();          //go back to the view page, by hiding the calendar 
            panel9.Visible = true;          //make the view page buttons and view page visible 
            panel5.Hide();                  //hide the edit form control buttons
            panel3.Show();
            panel10.Hide();                 //hide the edit form 
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void EditsReturned(object sender, EventArgs e)
        {
            panel10.Show();         //go back to the edits page for further edits
            panel5.Show();          //show the form for edits and the buttons for edits
            panel12.Hide();         //hide the edit confimation material
        }

        private void DeletionAccepted(object sender, EventArgs e)
        {
            string connStr = "server = csdatabase.eku.edu; user = addison_bradley19; database = bradley; port = 3306; password = Bradley19; ";      //connects to the database to delete from the database by connecting to the database and using the database selection for deletion
            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "DELETE FROM calendar WHERE eventID = @udate";
                MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@udate", eN);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            Console.WriteLine("Done.");     //bring back the main page 
            panel13.Hide();
            monthCalendar1.Visible = true;
            button1.Show();
            button2.Show();
            button3.Show();
            button4.Show();
            panel2.Visible = true;

            listBox1.Items.Clear();     //clear listbox so that none of the previous material will appear on the page

            ArrayList eventList = new ArrayList();  //a list to save the events
            //prepare an SQL query to retrieve all the events on the same, specified date
            DataTable myTable = new DataTable();
            string dateString = monthCalendar1.SelectionRange.Start.ToString("MM/dd/yyyy");     //get the event in format 01/01/2018
            
            MySqlConnection con = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT * FROM calendar WHERE date=@myDate ORDER BY startTime ASC";        //collect all events from calendar that match the selected date
                MySqlCommand cmd = new MySqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@myDate", dateString);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)           //save them to datatable and add them to eventlist
            {
                Event newEvent = new Event();
                newEvent.eventTitle = row["title"].ToString();
                newEvent.eventDate = row["date"].ToString();
                newEvent.eventStartTime = Int32.Parse(row["startTime"].ToString());
                newEvent.eventEndTime = Int32.Parse(row["endTime"].ToString());
                newEvent.eventContent = row["content"].ToString();
                newEvent.eventID = Int32.Parse(row["eventID"].ToString());
                newEvent.eventParticipants = row["participants"].ToString();
                newEvent.eventLocation = row["location"].ToString();
                newEvent.eventReminder = row["reminder"].ToString();
                eventList.Add(newEvent);
            }
            eList = eventList;      //return to eList
            //return eventList;  //return the event list
            for (int i = 0; i < eventList.Count; i++)       //display on the main page listbox
            {
                Event thisEvent = (Event)eventList[i];
                listBox1.Items.Add(thisEvent.getDate() + "    " + thisEvent.getTitle());
            }
            if (eList.Count != 0)       //make the first event the currently selected index, only if there is an index to select
            {
                listBox1.SelectedIndex = 0;
            }

        }

        private void EditsSaved(object sender, EventArgs e)
        {
            int cr = 0;
            nDate = textBox18.Text;       //all of the next couple of strings and values carry the values found in the user inputed areas
            nTitle = textBox17.Text;
            nlocation = textBox16.Text;
            nreminder = comboBox10.SelectedItem.ToString();
            nparticipants = textBox14.Text;
            nContent = textBox15.Text;
            string connStr = "server = csdatabase.eku.edu; user = addison_bradley19; database = bradley; port = 3306; password = Bradley19; ";
            MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr);      //connects the user to my database

            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open(); //open the connection
                string sql = "UPDATE calendar SET date = @udate, title = @utitle, reminder = @ureminder, location = @ulocation, participants = @uparticipants, content = @ucontent, startTime = @ustartTime, endTime = @uendTime WHERE eventID = @ueventID;";      //insert into the database
                MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@udate", nDate);       //add the values into the parameters
                cmd.Parameters.AddWithValue("@utitle", nTitle);
                cmd.Parameters.AddWithValue("@ureminder", nreminder);
                cmd.Parameters.AddWithValue("@ulocation", nlocation);
                cmd.Parameters.AddWithValue("@uparticipants", nparticipants);
                cmd.Parameters.AddWithValue("@ucontent", nContent);
                cmd.Parameters.AddWithValue("@ustartTime", stTime);
                cmd.Parameters.AddWithValue("@uendTime", enTime);
                cmd.Parameters.AddWithValue("@ueventID", eN);

                cmd.ExecuteNonQuery();      //execute query
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            Console.WriteLine("Done.");

            panel12.Hide();     //hide the edit form and button 
            monthCalendar1.Show();      //return to the main page
            panel2.Visible = true;
            button1.Show();
            button2.Show();
            button3.Show();
            button4.Show();

            listBox1.Items.Clear();     //clear main page list box so that new event matches what was selected by the user.

            ArrayList eventList = new ArrayList();  //a list to save the events
            //prepare an SQL query to retrieve all the events on the same, specified date
            DataTable myTable = new DataTable();
            string dateString = monthCalendar1.SelectionRange.Start.ToString("MM/dd/yyyy");

            MySqlConnection con = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT * FROM calendar WHERE date=@myDate ORDER BY startTime ASC";
                MySqlCommand cmd = new MySqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@myDate", dateString);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)
            {
                Event newEvent = new Event();
                newEvent.eventTitle = row["title"].ToString();
                newEvent.eventDate = row["date"].ToString();
                newEvent.eventStartTime = Int32.Parse(row["startTime"].ToString());
                newEvent.eventEndTime = Int32.Parse(row["endTime"].ToString());
                newEvent.eventContent = row["content"].ToString();
                newEvent.eventID = Int32.Parse(row["eventID"].ToString());
                newEvent.eventParticipants = row["participants"].ToString();
                newEvent.eventLocation = row["location"].ToString();
                newEvent.eventReminder = row["reminder"].ToString();
                eventList.Add(newEvent);
            }
            eList = eventList;
            //return eventList;  //return the event list
            for (int i = 0; i < eventList.Count; i++)
            {
                Event thisEvent = (Event)eventList[i];
                listBox1.Items.Add(thisEvent.getDate() + "    " + thisEvent.getTitle());
            }
            if (eList.Count != 0)
            {
                listBox1.SelectedIndex = 0;     //make first index
            }
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void contactRemoved(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox5.Text))      //if the textbox for the participants on the blank form is  not empty
            {
                string temp;
                temp = textBox5.Text;           //take the text currently inside the textbox
                string temp2 = comboBox6.SelectedItem.ToString() + ",";     //take the currently selected item within the participants comboxbox  of the blank form
                temp = temp.Replace(temp2,"");          //if the selected itme exists in the textbox's text, then remove it. Otherwise the action will be ignored
                textBox5.Text = temp;           //save the edits made
            }
        }

        private void EditContactAdded(object sender, EventArgs e)
        {
            if (!textBox14.Text.ToString().Contains(comboBox7.SelectedItem.ToString()))     //if there is no contact within edit participant textBox that matches the currently selected name in the edit paticipants comboBox, add it to the end of the textbox
            {
                textBox14.Text = textBox14.Text + comboBox7.SelectedItem.ToString() + ",";
            }
        }

        private void EditFinished(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox14.Text) || string.IsNullOrWhiteSpace(textBox15.Text) || string.IsNullOrWhiteSpace(textBox16.Text) || string.IsNullOrWhiteSpace(textBox17.Text) || string.IsNullOrWhiteSpace(textBox18.Text) || comboBox12.SelectedIndex == -1 || comboBox8.SelectedIndex == -1 || comboBox9.SelectedIndex == -1 || comboBox10.SelectedIndex == -1 || comboBox11.SelectedIndex == -1)       // makes sure there is something selected for all areas, such as the start time list box and the Event Title Textbox
            {
                Form3 form3 = new Form3();      //a form which informs the user that they have not completed everything and to go back and finish
                form3.Show();   //show said form
            }
            else
            {
                stTime = 0; //int to carry the 24 hour version of the start time
                enTime = 0; //int to carry the 24 hour version of the end time
                string m1 = comboBox9.SelectedItem.ToString();       //converts the user entered AM or PM to string
                string m2 = comboBox8.SelectedItem.ToString();
                stTime = sTime[comboBox12.SelectedIndex];             //converts the user selected times into ints
                enTime = sTime[comboBox11.SelectedIndex];

                if (m1 == "PM")             //if the user selects pm
                    stTime = stTime + 1200;     //add the equivalent of 12 extra hours or 1200
                if (m2 == "PM")
                    enTime = enTime + 1200;
                if ((stTime >= 1200 && stTime < 1300) || (stTime >= 2400 && stTime < 2500))     //if the time is twelve am or twelve Pm
                    stTime = stTime - 1200;     //subtracts them so that they are the correct time in the twelve hour spectrum
                if ((enTime >= 1200 && enTime < 1300) || (enTime >= 2400 && enTime < 2500))
                    enTime = enTime - 1200;
                if (((m1 == "PM") && (m2 == "AM")) || (stTime > enTime))        //stops the user from entering times that are either impossible or would lead the user to extending the event into the next day.
                {
                    Form10 form10 = new Form10();       //a form used to inform the user that the time entered is impossible
                    form10.Show();
                }
                else
                {
                    stAP = m1;          //save the AM or PM of the user
                    enAP = m2;          //save the AM or the PM of the user

                    monthCalendar1.Hide();      //hide the calendar so no further edits can be made
                    panel10.Hide();             //hide the blank form
                    panel5.Hide();              //hide buttons for blank form
                    panel12.Show();             //show save prompt
                }
            }
        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void EditContactRemoved(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox14.Text))         //if the there is nothing but white space in the eid box then do nothing.
            {
                string temp;                //however if there is something in the participants box, set up a string
                temp = textBox14.Text;         //collect the text currently in the participants textbox
                string temp2 = comboBox7.SelectedItem.ToString() + ",";     //take the currently selected item in the participants combo box of the edit page and turn that into a string. Add a comma to the end to match the style of the participants box.
                temp = temp.Replace(temp2, "");     //if there is somethign to remove that matches whats in the combobox, remove it from the string
                textBox14.Text = temp;      //put the current edits into the edit pages participant textbox to save the removal just preformed
            }
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
