//
//  EditorViewController.swift
//  CSC 308 Homework 6
//
//  Created by student on 10/27/16.
//  Copyright © 2016 cs.eku.edu. All rights reserved.
//

import UIKit

class EditorViewController: UIViewController {
    @IBOutlet weak var VehicleButton: UIButton!
    @IBOutlet weak var FoodButton: UIButton!
    @IBOutlet var FlowerButton: UIView!

    @IBAction func FlowerButtonPressed(sender: UIButton) {
        let vc = presentingViewController as! ViewController            //if flower button pressed, change the category
        vc.numOfCategory = 0                                            //image and change everything else
        let decider = arc4random_uniform(2)
        if(decider == 0){
            vc.numOfButt1 = vc.numOfCategory
            while (vc.numOfButt2 == vc.numOfCategory){
                vc.numOfButt2 = (Int)(arc4random_uniform((UInt32)(3)))
            }
        }
        else if(decider == 1){
            while (vc.numOfButt1 == vc.numOfCategory){
                vc.numOfButt1 = (Int)(arc4random_uniform((UInt32)(3)))
            }
            vc.numOfButt2 = vc.numOfCategory
        }
        let categoryPic = (Int)(arc4random_uniform(4))+1
        let nameOfCategoryImage = "\(vc.categoryArray[vc.numOfCategory])\(categoryPic).jpg"
        vc.categoryPicture.image = UIImage(named: nameOfCategoryImage)
        
        let Button1Pic = (Int)(arc4random_uniform(4))+1
        let nameOfButton1Image = "\(vc.categoryArray[vc.numOfButt1])\(Button1Pic).jpg"
        vc.ButtonOption1.setBackgroundImage(UIImage(named: nameOfButton1Image), forState: UIControlState.Normal)
        
        let Button2Pic = (Int)(arc4random_uniform((4)))+1
        let nameOfButton2Image = "\(vc.categoryArray[vc.numOfButt2])\(Button2Pic).jpg"
        vc.ButtonOption2.setBackgroundImage(UIImage(named: nameOfButton2Image), forState: UIControlState.Normal)
        
        dismissViewControllerAnimated(true, completion: nil)            //dismisses back to the last page
    }
    
    @IBAction func FoodButtonPressed(sender: UIButton) {            //same thing with Food
        let vc = presentingViewController as! ViewController
        vc.numOfCategory = 1
        let decider = arc4random_uniform(2)
        if(decider == 0){
            vc.numOfButt1 = vc.numOfCategory
            while (vc.numOfButt2 == vc.numOfCategory){
                vc.numOfButt2 = (Int)(arc4random_uniform((UInt32)(3)))
            }
        }
        else if(decider == 1){
            while (vc.numOfButt1 == vc.numOfCategory){
                vc.numOfButt1 = (Int)(arc4random_uniform((UInt32)(3)))
            }
            vc.numOfButt2 = vc.numOfCategory
        }
        let categoryPic = (Int)(arc4random_uniform(4))+1
        let nameOfCategoryImage = "\(vc.categoryArray[vc.numOfCategory])\(categoryPic).jpg"
        vc.categoryPicture.image = UIImage(named: nameOfCategoryImage)
        
        let Button1Pic = (Int)(arc4random_uniform(4))+1
        let nameOfButton1Image = "\(vc.categoryArray[vc.numOfButt1])\(Button1Pic).jpg"
        vc.ButtonOption1.setBackgroundImage(UIImage(named: nameOfButton1Image), forState: UIControlState.Normal)
        
        let Button2Pic = (Int)(arc4random_uniform((4)))+1
        let nameOfButton2Image = "\(vc.categoryArray[vc.numOfButt2])\(Button2Pic).jpg"
        vc.ButtonOption2.setBackgroundImage(UIImage(named: nameOfButton2Image), forState: UIControlState.Normal)
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func VehicleButtonPressed(sender: UIButton) { //same thing with vehicle
        let vc = presentingViewController as! ViewController
        vc.numOfCategory = 2
        let decider = arc4random_uniform(2)
        if(decider == 0){
            vc.numOfButt1 = vc.numOfCategory
            while (vc.numOfButt2 == vc.numOfCategory){
                vc.numOfButt2 = (Int)(arc4random_uniform((UInt32)(3)))
            }
        }
        else if(decider == 1){
            while (vc.numOfButt1 == vc.numOfCategory){
                vc.numOfButt1 = (Int)(arc4random_uniform((UInt32)(3)))
            }
            vc.numOfButt2 = vc.numOfCategory
        }
        let categoryPic = (Int)(arc4random_uniform(4))+1
        let nameOfCategoryImage = "\(vc.categoryArray[vc.numOfCategory])\(categoryPic).jpg"
        vc.categoryPicture.image = UIImage(named: nameOfCategoryImage)
        
        let Button1Pic = (Int)(arc4random_uniform(4))+1
        let nameOfButton1Image = "\(vc.categoryArray[vc.numOfButt1])\(Button1Pic).jpg"
        vc.ButtonOption1.setBackgroundImage(UIImage(named: nameOfButton1Image), forState: UIControlState.Normal)
        
        let Button2Pic = (Int)(arc4random_uniform((4)))+1
        let nameOfButton2Image = "\(vc.categoryArray[vc.numOfButt2])\(Button2Pic).jpg"
        vc.ButtonOption2.setBackgroundImage(UIImage(named: nameOfButton2Image), forState: UIControlState.Normal)
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
