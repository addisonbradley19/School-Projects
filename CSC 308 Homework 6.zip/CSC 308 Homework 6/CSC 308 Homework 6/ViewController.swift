//
//  ViewController.swift
//  CSC 308 Homework 6
//
//  Created by student on 10/27/16.
//  Copyright © 2016 cs.eku.edu. All rights reserved.
//
//Name: Addison Bradley
//Class: CSC 308
//Date: 10/31/2016
//Project: Homework 6
//Goal: Create a game to match categories based on picture, and have user pick pictures and categories from button presses

import UIKit

class ViewController: UIViewController {
    let categoryArray = ["Flower", "Food", "Vehicle"]       //array of all category names
    @IBOutlet weak var ChangeCategoryButton: UIButton!      //button for changing categories
    @IBOutlet weak var categoryPicture: UIImageView!        //the picture of top category
    @IBOutlet weak var ButtonOption1: UIButton!             //the two buttons that the user is allowed to press
    @IBOutlet weak var ButtonOption2: UIButton!
    @IBOutlet weak var changePictureButton: UIButton!       //button for changing pictures
    var numOfCategory: Int = 0;                             //number to represent the category
    var numOfButt1: Int = 0;                                //number to represent either number
    var numOfButt2: Int = 0;
    
    @IBAction func Button1Pressed(sender: UIButton) {               //if button 1 is pressed...
        if(numOfCategory == numOfButt1){                            //and it matches the number of the category selected
            let alertMC = UIAlertController(                        //Message of correct answer is given
                title: "Thank you",
                message: "Congratulations! You are correct!",
                preferredStyle: UIAlertControllerStyle.Alert)
            let defaultA = UIAlertAction(title: "OK", style: UIAlertActionStyle.Cancel, handler: nil)
            alertMC.addAction(defaultA)
            presentViewController(alertMC, animated: true, completion: nil)
        }
        else{
            let alertMC = UIAlertController(                        //if the answer is wrong, a message telling the user 
                                                                    //that they wrong pops up
                title: "Thank you",
                message: "Sorry, you are wrong!",
                preferredStyle: UIAlertControllerStyle.Alert)
            let defaultA = UIAlertAction(title: "OK", style: UIAlertActionStyle.Cancel, handler: nil)
            alertMC.addAction(defaultA)
            presentViewController(alertMC, animated: true, completion: nil)
        }
        let decider = arc4random_uniform(2)                     //changes everything except the category of the category    
                                                                //picture
        if(decider == 0){
            numOfButt1 = numOfCategory
            numOfButt2 = (Int)(arc4random_uniform((UInt32)(3)))
            while (numOfButt2 == numOfCategory){
                numOfButt2 = (Int)(arc4random_uniform((UInt32)(3)))
            }
        }
        else if(decider == 1){
            numOfButt1 == (Int)(arc4random_uniform((UInt32)(3)))
            while (numOfButt1 == numOfCategory){
                numOfButt1 = (Int)(arc4random_uniform((UInt32)(3)))
            }
            numOfButt2 = numOfCategory
        }
        let categoryPic = (Int)(arc4random_uniform(4))+1
        let nameOfCategoryImage = "\(categoryArray[numOfCategory])\(categoryPic).jpg"
        categoryPicture.image = UIImage(named: nameOfCategoryImage)
        
        let Button1Pic = (Int)(arc4random_uniform(4))+1
        let nameOfButton1Image = "\(categoryArray[numOfButt1])\(Button1Pic).jpg"
        ButtonOption1.setBackgroundImage(UIImage(named: nameOfButton1Image), forState: UIControlState.Normal)
        
        let Button2Pic = (Int)(arc4random_uniform((4)))+1
        let nameOfButton2Image = "\(categoryArray[numOfButt2])\(Button2Pic).jpg"
        ButtonOption2.setBackgroundImage(UIImage(named: nameOfButton2Image), forState: UIControlState.Normal)
    }
    
    @IBAction func Button2Pressed(sender: UIButton) {       //everything that occured if button 1
        if(numOfCategory == numOfButt2){                    //was pressed occurs if button 2
            let alertMC = UIAlertController(                //was pressed
                title: "Thank you",
                message: "Congratulations! You are correct!",
                preferredStyle: UIAlertControllerStyle.Alert)
            let defaultA = UIAlertAction(title: "OK", style: UIAlertActionStyle.Cancel, handler: nil)
            alertMC.addAction(defaultA)
            presentViewController(alertMC, animated: true, completion: nil)
        }
        else{
            let alertMC = UIAlertController(
                title: "Thank you",
                message: "Sorry, you are wrong!",
                preferredStyle: UIAlertControllerStyle.Alert)
            let defaultA = UIAlertAction(title: "OK", style: UIAlertActionStyle.Cancel, handler: nil)
            alertMC.addAction(defaultA)
            presentViewController(alertMC, animated: true, completion: nil)
        }
        
        let decider = arc4random_uniform(2)
        if(decider == 0){
            numOfButt1 = numOfCategory
            numOfButt2 = (Int)(arc4random_uniform((UInt32)(3)))
            while (numOfButt2 == numOfCategory){
                numOfButt2 = (Int)(arc4random_uniform((UInt32)(3)))
            }
        }
        else if(decider == 1){
            numOfButt1 == (Int)(arc4random_uniform((UInt32)(3)))
            while (numOfButt1 == numOfCategory){
                numOfButt1 = (Int)(arc4random_uniform((UInt32)(3)))
            }
            numOfButt2 = numOfCategory
        }
        let categoryPic = (Int)(arc4random_uniform(4))+1
        let nameOfCategoryImage = "\(categoryArray[numOfCategory])\(categoryPic).jpg"
        categoryPicture.image = UIImage(named: nameOfCategoryImage)
        
        let Button1Pic = (Int)(arc4random_uniform(4))+1
        let nameOfButton1Image = "\(categoryArray[numOfButt1])\(Button1Pic).jpg"
        ButtonOption1.setBackgroundImage(UIImage(named: nameOfButton1Image), forState: UIControlState.Normal)
        
        let Button2Pic = (Int)(arc4random_uniform((4)))+1
        let nameOfButton2Image = "\(categoryArray[numOfButt2])\(Button2Pic).jpg"
        ButtonOption2.setBackgroundImage(UIImage(named: nameOfButton2Image), forState: UIControlState.Normal)
    }
    
    
    @IBAction func changePictureButtonPressed(sender: UIButton) {                       //if the picture button is
        let categoryPic = (Int)(arc4random_uniform(4))+1                                //pressed,
        let nameOfCategoryImage = "\(categoryArray[numOfCategory])\(categoryPic).jpg"   //only pictures change
        categoryPicture.image = UIImage(named: nameOfCategoryImage)
        
        let Button1Pic = (Int)(arc4random_uniform((4)))+1
        let nameOfButton1Image = "\(categoryArray[numOfButt1])\(Button1Pic).jpg"
        ButtonOption1.setBackgroundImage(UIImage(named: nameOfButton1Image), forState: UIControlState.Normal)
        
        let Button2Pic = (Int)(arc4random_uniform((4)))+1
        let nameOfButton2Image = "\(categoryArray[numOfButt2])\(Button2Pic).jpg"
        ButtonOption2.setBackgroundImage(UIImage(named: nameOfButton2Image), forState: UIControlState.Normal)
    }
    
    
    @IBAction func changeCategory(sender: UIButton) {
        performSegueWithIdentifier("ToCategory", sender: sender)          //switches over to the second screen
    }                                                                   //to provide category changes
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }

    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        numOfCategory = (Int)(arc4random_uniform((UInt32)(3)))          //selects a category for the button out of 0-2
        let decider = arc4random_uniform(2)                             //metphorically flips a coin to see who is
        if(decider == 0){                                               //the matching category with category pic
            numOfButt1 = numOfCategory
            while (numOfButt2 == numOfCategory){                        //uses a while loop to get a number that is not
                numOfButt2 = (Int)(arc4random_uniform((UInt32)(3)))     //the number for the top category
            }
        }
        else if(decider == 1){
            while (numOfButt1 == numOfCategory){
                numOfButt1 = (Int)(arc4random_uniform((UInt32)(3)))
            }
            numOfButt2 = numOfCategory
        }
        let categoryPic = (Int)(arc4random_uniform(4))+1                    //number of the picture 1-5
        let nameOfCategoryImage = "\(categoryArray[numOfCategory])\(categoryPic).jpg"//custom makes the name based
        categoryPicture.image = UIImage(named: nameOfCategoryImage)             //makes it the image
        
        let Button1Pic = (Int)(arc4random_uniform(4))+1         //same with button, but instead the background image
        let nameOfButton1Image = "\(categoryArray[numOfButt1])\(Button1Pic).jpg"
        ButtonOption1.setBackgroundImage(UIImage(named: nameOfButton1Image), forState: UIControlState.Normal)
        
        let Button2Pic = (Int)(arc4random_uniform((4)))+1
        let nameOfButton2Image = "\(categoryArray[numOfButt2])\(Button2Pic).jpg"
        ButtonOption2.setBackgroundImage(UIImage(named: nameOfButton2Image), forState: UIControlState.Normal)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

