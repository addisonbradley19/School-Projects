import requests
import csv
import time

try:
    ips = open("C:/Users/addis/PycharmProjects/Virus_Total/IPs_list.csv", "r")
except:
    print ('File not found')

try:
    reader1 = csv.reader(ips, delimiter=",")

except:
    print ("Exception")

attempts= 0

for line in reader1:
    ip_to_check = line[0]
    headers = {
      "Accept-Encoding": "gzip, deflate",
      "User-Agent" : "gzip,  My Python requests library example client or username"
      }
    try:
        attempts = attempts + 1
        if attempts > 4:
            time.sleep(60)
            attempts = 1
        params = {'apikey': '498ed17765a0cb6fd69e839245b405dbe670e0a916eb264fc8c5e41e2bc2d552', 'resource':'http://'+ip_to_check}
        response = requests.post('https://www.virustotal.com/vtapi/v2/url/report',
        params=params, headers=headers)
        json_response = response.json()
        print (ip_to_check,json_response["positives"])

    except:
        print ("Error")

