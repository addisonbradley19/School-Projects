//Name: Addison Bradley
//Class: CSC 400
//Date: 10/1/2017
//Student #: 901542965
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>

#define MAX_BUFFER 1024                        // max line buffer
#define MAX_ARGS 64                            // max # args
#define SEPARATORS " \t\n"                     // token sparators
#define clear() printf("\033[H\033[J")		//used as the means for clearing the screen, user calls clear() and print is done which gives the clear command

char string[MAX_BUFFER];			//used to hold the user inputed string, is as big as the maximum bufffer
char *str;				//used to hold the first part of string which is the command input
char *s;				//used to hold the second part of the string that is used in echo, dir, and cd
char c[5] = "cd";			//strings c,d,cl,ex,ec are used for comparisions of str to determine which activity to perform
char d[5] = "dir";
char cl[5] = "clr";
char ex[6] = "quit";
char ec[6] = "echo";		
char wm[40] = "Sorry that command does not exist";	//used to when there is an error
char beg[30] = "Welcome to Operating System";		//used as a beginning
char *lit = " ";					//used as representation of a blank spot to be used when			 
char *mfd = "\0";
char *token;
char linebuf[MAX_BUFFER];                  // line buffer
char cwdbuf[MAX_BUFFER];                   // cwd buffer
char * args[MAX_ARGS];                     // pointers to arg strings
char ** arg;                               // working pointer thru args
char * prompt = "==>" ;                    // shell prompt




void errmsg(char * msg1, char * msg2)			//used for printing of the actual error 							//messages
{
    fprintf(stderr,"ERROR: ");
    if (msg1)
        fprintf(stderr,"%s; ", msg1);
    if (msg2)
        fprintf(stderr,"%s; ", msg2);
    return;
    fprintf(stderr,"\n");
}


void syserrmsg(char * msg1, char * msg2)
{
    errmsg(msg1, msg2);			//take error information and create the message
    perror(NULL);
    return;				//go back to the loop
}



void cd(bool bgstatus){
	int status;
    	pid_t child_pid;
	if(!s){			//if there is nothing in the second string
		switch (child_pid = fork()) {
        		case -1:
        		    syserrmsg("fork",NULL);		//fork and print of the current directory or give an error
        		    break;
        		case 0:          
		 	  	if (getcwd(cwdbuf, sizeof(cwdbuf)))
		        	        printf("%s\n", cwdbuf); // print cwd
		        	else
		        	       syserrmsg("retrieving cwd",NULL);
				 _exit(0);
		}
		if (!bgstatus) waitpid(child_pid, &status, WUNTRACED);
	}
	else{			//else if there is something in the s string
		if(chdir(s)){	//but it is not an actual directory
			switch (child_pid = fork()) {
        			case -1:
        			    syserrmsg("fork",NULL);
        			    break;
        			case 0:          
			 	  	syserrmsg("change directory failed",NULL);		//write an error
					 _exit(0);
			}
			if (!bgstatus) waitpid(child_pid, &status, WUNTRACED);
		}
		else{		//if it actually changed the directory
			 strcpy(cwdbuf,"PWD="); // Then it is time to set the backgroun
			 if ((getcwd(&cwdbuf[4], sizeof(cwdbuf)-4))) {
                                if (putenv(strdup(cwdbuf))){
				    switch (child_pid = fork()) {
					case -1:
					    syserrmsg("fork",NULL);
					    break;
					case 0:
                                    	    syserrmsg("change of PWD environment variable failed",NULL);
					    _exit(0);
				    }
				  if (!bgstatus) waitpid(child_pid, &status, WUNTRACED);
				}
                         }
			else{
				switch (child_pid = fork()) {
        				case -1:
        				    syserrmsg("fork",NULL);
        				    break;
        				case 0:          
			 		  	syserrmsg("change directory failed",NULL);
						_exit(0);
				}
				if (!bgstatus) waitpid(child_pid, &status, WUNTRACED);
			} 
		}
	}	
	
}



void clr(bool bgstatus){
	int status;
    	pid_t pid3;

    	switch (pid3 = fork()) {
        	case -1:
        	    syserrmsg("fork",NULL);
        	    break;
        	case 0:
		    execlp("/usr/bin/clear", "clear",NULL);	//clear	the screen
    	}
       if (!bgstatus) waitpid(pid3, &status, WUNTRACED);
}


void dir(bool bgstatus){
	int status;
	pid_t	pid;

    	switch (pid = fork()) {			//fork the process
        	case -1:
        	    syserrmsg("fork",NULL);			//in case of fork error
        	    break;
        	case 0:
			if(!s){						//if there is nothing in the second string
	   			execlp("/bin/ls","ls",NULL);		//show all contents of the current directory
			}
			else{						//otherwise
				execlp("/bin/ls","ls",s,NULL);		//show all contents of the directory of your choice
			}
			_exit(0);			//end child process
    	}
	if (!bgstatus) waitpid(pid, &status, WUNTRACED);		//if foreground, wait until child is finished.
}

void echo(bool bgstatus){
	int status;
    	pid_t pid4;
	switch (pid4 = fork()) {		//fork
        	case -1:
            		syserrmsg("fork",NULL);			//in case of fork failure
           		break;
        	case 0:
			if(!s){
	   			printf("\n");		//if nothing is in the second string, print nothing but a blank space
			}	
			else{
			   printf("%s\n",s);		//otherwise print the string
			}
			_exit(0);			//end the child process
	   		
    	}
    	
    	if (!bgstatus) waitpid(pid4, &status, WUNTRACED);	//if foreground execution, wait until the echo is printed
}




int main()
{ 
  	printf("%s\n",beg);			//print introduction
	bool bgstatus;                             // background or foreground
  
	while (!feof(stdin)) {
	  if(getcwd(cwdbuf, sizeof(cwdbuf)))   // read current working directory
		printf("%s%s", cwdbuf,prompt);   // output as prompt
	  else
		printf("getcwd ERROR %s",prompt);
	 bgstatus = false;   // foreground execution
	
	  gets(string);		//collect user input
	  if (string[strlen(string)-1] == '&') {		//checks to see if there is a 
               bgstatus = true;					//if so sets the background or foreground boolean to true for background
	       string[strlen(string)-1] = NULL;			//replaces the with an empty space so that it is not used during any actual programs
	  }
	  str = strtok(string,lit);
	  s = strtok(NULL,mfd);		//store the string into two parts
					//second part is everything after the first space
				//stops the tokenize at sign of mfd which is \0
	if(!str) continue;
	  if(strcmp(str,c) == 0){			//if the first part equals c which is cd
						//which begins the change directory protocol
		cd(bgstatus);
	  }
	  else if(strcmp(str,cl) == 0){		//if the first part of the user inputted string equals clr, perform clear screen action
		clr(bgstatus);
	  }
	  else if(strcmp(str,d) == 0){		//if the first part of the user input is dir then 							//it activates the print current directory contents action
		dir(bgstatus);
	  }
	  else if(strcmp(str,ec) == 0){		//if the first part of the user input equals echo
						//print second part of string
		echo(bgstatus);
	  }
	  else if(strcmp(str,ex) == 0){		//if the user chooses exit, the user will break from the loop and will exit the program
		break;
	  }
	  
	  else{					//if the user has entered a command that does not exist, the program will inform them that it does not exist
		system(string);
	  }

	}
	return 0;
}
